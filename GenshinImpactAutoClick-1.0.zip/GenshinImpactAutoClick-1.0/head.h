#pragma once
//�������
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <windows.h>
#include <stdlib.h>
#include <thread>
#include <ctime>
#include <string>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
using namespace std;
#include "resource.h"

#ifndef MYFILE_H
#define MYFILE_H

void showMenu();
void showError();
void Times();
void Awex();

#endif
